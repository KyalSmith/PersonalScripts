import getpass
import cx_Oracle
import datetime
import xlwt
import os
from O365 import Message
from O365 import Attachment


def main():

    loginFile()
    user1, pass1 = UserCredentials()
    fileName = CreateFileName()
    queries = GetQueries()
    Message = ""
    user1 = user1.rstrip()
    pass1 = pass1.rstrip()
    tmpResult = [['']]*(len(queries))
    finalOutput = [['']]*(len(queries))
    outputResults = ['']*7

    for count,item in enumerate(queries):
        tmpResult[count] = OracleResults(user1,pass1,item)


    for countOuter in range(0,len(tmpResult)):
        val = len(tmpResult[countOuter])
        tmpStore = []
        for i in range(val):
            tmpStore.append([])

        for countInner in range(0,len(tmpResult[countOuter])):

            for x in range(0,len(tmpResult[countOuter][countInner])):

                if isinstance(tmpResult[countOuter][countInner][x], datetime.date):

                    t = tmpResult[countOuter][countInner][x]
                    t = t.strftime('%m/%d/%Y')
                    outputResults[x] = t

                else:
                    outputResults[x] = str(tmpResult[countOuter][countInner][x])
                '''if x == 6:
                    break;'''
            tmpStore[countInner]= tuple(outputResults)

        finalOutput[countOuter] = tmpStore

    ToExcel(fileName,finalOutput)
    for item in finalOutput:
        if not item:
            Message += "\n\nCVM Check:\n"
            break;
    if not finalOutput[0]:
        Message += "Note: Currently no Results for the GMR Wrapper"
    if not finalOutput[1]:
        Message += "Note: Currently no Results for the IBCI Wrapper"
    if not finalOutput[2]:
        Message += "Note: Currently no Results for the IBCM Wrapper"
    if not finalOutput[3]:
        Message += "Note: Currently no Results for the IBCP Wrapper"
    if not finalOutput[4]:
        Message += "Note: Currently no Results for the IMC Wrapper"
    if not finalOutput[5]:
        Message += "Note: Currently no Results for the NTFI Wrapper"
    if not finalOutput[6]:
        Message += "Note: Currently no Results for the OCS Wrapper"
    if not finalOutput[7]:
        Message += "Note: Currently no Results for the IBIM Wrapper"
    if not finalOutput[8]:
        Message += "Note: Currently no Results for the ILM Wrapper"
    if not finalOutput[9]:
        Message += "Note: Currently no Results for the MCCM Wrapper"
    if not finalOutput[10]:
        Message += "Note: Currently no Results for the PMG Wrapper"
    if not finalOutput[11]:
        Message += "Note: Currently no Results for the SMS Wrapper"
    if not finalOutput[12]:
        Message += "Note: Currently no Results for the RTI(1,2) Wrapper"
    if not finalOutput[13]:
        Message += "Note: Currently no Results for the RTI(3) Wrapper"
    if not finalOutput[14]:
        Message += "Note: Currently no Results for the CIS Wrapper"
    if not finalOutput[15]:
        Message += "Note: Currently no Results for the MMSG Wrapper"
    
    return fileName,Message




def UserCredentials():
    user1=""
    pass1=""
    passFile = open('/var/www/Scripts/AllScripts/Misc/CVMpass.txt', 'r')
    for value in passFile:
        line = value.split(':')
        if line[0] == 'Username':
            user1 = line[1]
        elif line[0] == 'Password':
            pass1 = line[1]
    
    passFile.close()
    return user1,pass1

def GetQueries():
    queriesFile = open("/var/www/Scripts/AllScripts/Misc/CVMCheckQuery.txt", 'r')
    tmpQueries = ""
    for item in queriesFile:
        tmpQueries += item
    queries = tmpQueries.split('\n:\n')
    return queries


def CreateFileName():
    timeDate = datetime.datetime.now()
    date = " %s-%s-%s " % (timeDate.day, timeDate.month, timeDate.year)
    time = "%sH%sM%sS" % (timeDate.hour, timeDate.minute, timeDate.second)
    exelFile = "CVMCheck"
    fileName = exelFile + "-" + str(date) + "-" + str(time) + ".xls"

    return fileName


def loginFile():

    try:
        f = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt", 'r')
        f.close()


    except Exception:
        f = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt", 'w')
        f.close()
        setPassword()



def setPassword():
    passWrite = open('/var/www/Scripts/AllScripts/Misc/CVMpass.txt', 'w')
    user1 = input("Please input username: ")
    pass1 = getpass.getpass('Password:')
    passWrite.write("Username:" + user1 + "\n")
    passWrite.write("Password:" + pass1)
    passWrite.close()
    
    


def OracleResults(user1,pass1,query):
    user1 = user1.rstrip()
    pass1 = pass1.rstrip()
    con = cx_Oracle.connect(user1,pass1,dsn='Server IP:1521/Oracle TNS ')
    cur = con.cursor()

    tmp = cur.execute(query)
    results = tmp.fetchall()

    con.close()
    return results


def ToExcel(fileName,data):

    book = xlwt.Workbook()
    GMR = book.add_sheet("GMR")
    IBCI = book.add_sheet("IBCI")
    IBCM = book.add_sheet("IBCM")
    IBCP = book.add_sheet("IBCP")
    IMC = book.add_sheet("IMC")
    NTFI = book.add_sheet("NTFI")
    OCS = book.add_sheet("OCS")
    IBIM = book.add_sheet("IBIM")
    ILM = book.add_sheet("ILM")
    MCCM = book.add_sheet("MCCM")
    PMG = book.add_sheet("PMG")
    SMS = book.add_sheet("SMS")
    RTI12 = book.add_sheet("RTI 1 and 2")
    RTI3 = book.add_sheet("RTI 3")
    CIS = book.add_sheet("CIS")
    MMSG = book.add_sheet("MMSG")
    switcher = {0:GMR,1:IBCI,2:IBCM,3:IBCP,4:IMC,5:NTFI,6:OCS,7:IBIM,8:ILM,9:MCCM,10:PMG,11:SMS,12:RTI12,13:RTI3,14:CIS,15:MMSG}
    style = xlwt.easyxf('font: bold 1,height 280')
    headers = ["Date:","Hour:","TXN_Type:","Server_Name:","TXN_Count:","EXP_Count:","EXP_Percent:"]
    for countOuter in range(0,len(data)):

        for count in range(0,7):
            switcher[countOuter].write(0,count,str(headers[count]),style)
            switcher[countOuter].col(count).width = 512 * (len(headers[count])+1)


        for countInner in range(0,len(data[countOuter])):

            for finalCount in range(0,len(data[countOuter][countInner])):
                switcher[countOuter].write(countInner+1,finalCount,str(data[countOuter][countInner][finalCount]))

    book.save("/var/www/Scripts/AllScripts/Attachments/"+str(fileName))




def MailFunc(message,FileName):
    testTime = datetime.datetime.now()
    testTime = str(testTime)
    testTime = testTime.split(' ')
    time = testTime[1]
    time1 = time.split(':')
    
    recipients = []
    cwd = os.getcwd()
    

    if (time1[0]=="9" and time1[1]=="36") or (time1[0]=="12" and time1[1]=="00") or (time1[0]=="16" and time1[1]=="00"):
        recipients = ['']
    else :
        recipients = ['']

    authentication = ('email address','password')
    
    attach = Attachment(path = FileName)
    m = Message(auth = authentication)
    m.setRecipients(recipients)
    m.setBody(message)
    m.setSubject("CVM Check Results")
    m.attachments.append(attach)
    m.sendMessage()

    #"Kyal.Smith@altron.com;Michael.Hall@altron.com;Brent.Arendse@altron.com"#mccmsal1@vodacom.co.za;Brent.Arendse@altron.com;Michael.Hall@altron.com


if __name__=="__main__":
    main()
