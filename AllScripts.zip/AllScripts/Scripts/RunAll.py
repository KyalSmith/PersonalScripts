import threading
import os
import datetime
import CVMCheck
import DSECheck  
import DSE_File_Loaded
import PendingSMS
import PrevDayCheck
import ETLCheck
from O365 import Attachment
from O365 import Message

def RunAll():
    Procs = [CVMCheck,DSECheck,DSE_File_Loaded,PendingSMS,PrevDayCheck,ETLCheck]
    t = []
    values = []
    for i in Procs:
        t.append(threads(target=i.main))
    for i in t:
        i.start()
    for i in t:
        values.append(i.join())
    print(values)


    MailFunc(values)


def MailFunc(results):
    message =""


    for val in results:
        message += str(val[1])
    recipients = ['BUStelCVMSupport@altron.com', 'francois.duplessis@vodacom.co.za']#

    authentication = ('Kyal.Smith@altron.com','loatsu666!')
    attachyStuff = []
    for attach in results:
        attachyStuff.append(attach)
    
    m = Message(auth = authentication)
    m.setRecipients(recipients)
    try:
        readCim = open("/var/www/Scripts/AllScripts/Attachments/CimFileName.txt",'r')
        cimFile = readCim.readline()
        cimFile = cimFile.split(':')
        print("CimFile[0]: "+cimFile[0]+"\nCimFile[1]: "+cimFile[1])
        message += "\n\nCIM Backlog Check:\n"+cimFile[1]
        readCim.close()
        attachCIM = Attachment(path="/var/www/Scripts/AllScripts/Attachments/" + cimFile[0])
        m.attachments.append((attachCIM))
    except Exception as e:
        print(e)
    m.setBody("Please see attachments for the For the Hourly Checks.\n\n"+message)
    m.setSubject("Hourly Checks")
    for val in attachyStuff:
        attach = Attachment(path = "/var/www/Scripts/AllScripts/Attachments/"+str(val[0]))
        m.attachments.append(attach)

    m.sendMessage()



class threads(threading.Thread):
    def __init__(self,target):
        threading.Thread.__init__(self)
        self._target = target


    def run(self):
        self.ret = self._target()

    def join(self):
        threading.Thread.join(self)
        return self.ret

if __name__=="__main__":
    RunAll()

