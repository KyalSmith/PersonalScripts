import threading


def main():
    t = threads(target=whatever())
    t.start()
    print(t.join())









def whatever():
    print("whatever!")
    return 5




if __name__=="__main__":
    main()