import getpass
import cx_Oracle
import datetime
import xlwt
import os
from O365 import Message
from O365 import Attachment


def main():

    loginFile()
    user1, pass1 = UserCredentials()
    fileName = CreateFileName()
    queries = GetQueries()
    Message = ""

    tmpResult = [['']]*(len(queries))
    finalOutput = [['']]*(len(queries))
    outputResults = ['']*7

    for count,item in enumerate(queries):
        tmpResult[count] = OracleResults(user1,pass1,item)


    for countOuter in range(0,len(tmpResult)):
        val = len(tmpResult[countOuter])
        tmpStore = []
        for i in range(val):
            tmpStore.append([])

        for countInner in range(0,len(tmpResult[countOuter])):

            for x in range(0,len(tmpResult[countOuter][countInner])):

                if isinstance(tmpResult[countOuter][countInner][x], datetime.date):

                    t = tmpResult[countOuter][countInner][x]
                    t = t.strftime('%m/%d/%Y')
                    outputResults[x] = t

                else:
                    outputResults[x] = str(tmpResult[countOuter][countInner][x])
                '''if x == 6:
                    break;'''
            tmpStore[countInner]= tuple(outputResults)

        finalOutput[countOuter] = tmpStore

    ToExcel(fileName,finalOutput)
    for item in finalOutput:
        if not item:
            Message+="\n\nDSE Check:\n"
            break;
    if not finalOutput[0]:
        Message += "Note: Currently no Results for the DCE Wrapper"
    if not finalOutput[1]:
        Message += "Note: Currently no Results for the Siebel Wrapper"
    if not finalOutput[2]:
        Message += "Note: Currently no Results for the IBIM Wrapper"
    if not finalOutput[3]:
        Message += "Note: Currently no Results for the SOM Wrapper"
    #MailFunc(Message+"\n\nThank You",fileName)
    return fileName,Message



def UserCredentials():
    user1 = ""
    pass1 = ""
    passFile = open('/var/www/Scripts/AllScripts/Misc/DSEcheckPass.txt', 'r')
    for value in passFile:
        line = value.split(':')
        if line[0] == 'Username':
            user1 = line[1]
        elif line[0] == 'Password':
            pass1 = line[1]
    user1 = user1.rstrip()
    pass1 = pass1.rstrip()
    passFile.close()
    return user1,pass1

def GetQueries():
    queriesFile = open("/var/www/Scripts/AllScripts/Misc/DSECheckQuery.txt", 'r')
    tmpQueries = ""
    for item in queriesFile:
        tmpQueries += item
    queries = tmpQueries.split(':')
    return queries


def CreateFileName():
    timeDate = datetime.datetime.now()
    date = " %s-%s-%s " % (timeDate.day, timeDate.month, timeDate.year)
    time = "%sH%sM%sS" % (timeDate.hour, timeDate.minute, timeDate.second)
    exelFile = "DSECheck"
    fileName = exelFile + "-" + str(date) + "-" + str(time) + ".xls"

    return fileName


def loginFile():

    try:
        f = open("/var/www/Scripts/AllScripts/Misc/DSEcheckPass.txt", 'r')
        f.close()


    except Exception:
        f = open("/var/www/Scripts/AllScripts/Misc/DSEcheckPass.txt", 'w')
        f.close()
        setPassword()



def setPassword():
    passWrite = open('/var/www/Scripts/AllScripts/Misc/DSEcheckPass.txt', 'w')
    user1 = input("Please input username: ")
    pass1 = getpass.getpass('Password:')
    passWrite.write("Username:" + user1 + "\n")
    passWrite.write("Password:" + pass1)
    passWrite.close()
   

def OracleResults(user1,pass1,query):

    con = cx_Oracle.connect(user1,pass1,dsn='10.132.97.29:1521/mccmsprd')
    cur = con.cursor()

    tmp = cur.execute(query)
    results = tmp.fetchall()

    con.close()
    return results


def ToExcel(fileName,data):

    book = xlwt.Workbook()
    dce = book.add_sheet("DCE")
    siebel = book.add_sheet("Siebel")
    ibim = book.add_sheet("IBIM")
    som = book.add_sheet("SOM")
    switcher = {0:dce,1:siebel,2:ibim,3:som}
    style = xlwt.easyxf('font: bold 1,height 280')
    headers = ["Date:","Hour:","TXN_Type:","Server_Name:","TXN_Count:","EXP_Count:","EXP_Percent:"]
    for countOuter in range(0,len(data)):

        for count in range(0,7):
            switcher[countOuter].write(0,count,str(headers[count]),style)
            switcher[countOuter].col(count).width = 512 * (len(headers[count])+1)


        for countInner in range(0,len(data[countOuter])):

            for finalCount in range(0,len(data[countOuter][countInner])):
                switcher[countOuter].write(countInner+1,finalCount,str(data[countOuter][countInner][finalCount]))

    book.save("/var/www/Scripts/AllScripts/Attachments/"+fileName)




def MailFunc(message,FileName):
    testTime = datetime.datetime.now()
    testTime = str(testTime)
    testTime = testTime.split(' ')
    time = testTime[1]
    time1 = time.split(':')

    recipients = []
    cwd = os.getcwd()
    

    if (time1[0]=="9" and time1[1]=="37")or(time1[0]=="12" and time1[1]=="00")or (time1[0]=="16" and time1[1]=="00"):
        recipients = ['BUStelCVMSupport@altron.com','francois.duplessis@vodacom.co.za']
    else :
        recipients = ['BUStelCVMSupport@altron.com']

    authentication = ('Kyal.Smith@altron.com','Inv4d3rZ1m123!')
    m = Message(auth=authentication)
    att = Attachment(path = FileName)
    m.setRecipients(recipients)
    m.setSubject('DSE Check')
    m.setBody(message)
    m.attachments.append(att)
    m.sendMessage()
    print("Email Sent")
	
	
	

if __name__=="__main__":
    main()
