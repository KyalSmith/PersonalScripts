import cx_Oracle
import getpass
import datetime
import xlwt
from O365 import Attachment
from O365 import Message

'''  while True:
        time_test = datetime.datetime.now()
        time = str(time_test.time())
        time = time[:8]
        time = time[-5:]
        if time == "00:00":'''
def main():
    loginFile()
    user1, pass1 = UserCredentials()
    results = [[''],['']]
    file_name = CreateFileName()
    message = ""
    query = """SELECT Process_Name, Target_Table, Loaded_Records, Start_Time, End_Time, StatusCode, StatusReason
FROM dse.Dse_History_Table t
where t.start_time >= trunc(sysdate)
ORDER BY Id DESC
"""
    OracleResults(user1,pass1,query,results)
    if not results:
        message = "\n\nDSE File Check:\nPlease note there were NO results found for DSE Query!"
    ToExcel(results,file_name)
    #MailFunc(file_name,message)
    return file_name,message








def loginFile():
    try:
        f = open("/var/www/Scripts/AllScripts/Misc/DSEcheckPass.txt", 'r')
        f.close()


    except Exception:
        f = open("/var/www/Scripts/AllScripts/Misc/DSEcheckPass.txt", 'w')
        f.close()
        setPassword()


def UserCredentials():
    passFile = open('/var/www/Scripts/AllScripts/Misc/DSEcheckPass.txt', 'r')
    for value in passFile:
        line = value.split(':')
        if line[0] == 'Username':
            user1 = line[1]
        elif line[0] == 'Password':
            pass1 = line[1]
    user1 = user1.rstrip()
    pass1 = pass1.rstrip()
    passFile.close()
    return user1,pass1

def CreateFileName():
    timeDate = datetime.datetime.now()
    date = " %s-%s-%s " % (timeDate.day, timeDate.month, timeDate.year)
    time = "%sH%sM%sS" % (timeDate.hour, timeDate.minute, timeDate.second)
    exelFile = "DSEFileStatus"
    fileName = exelFile + "-" + str(date) + "-" + str(time) + ".xls"

    return fileName

def OracleResults(user1,pass1,query,results):
    con = cx_Oracle.connect(user1,pass1,dsn='10.132.97.29:1521/mccmsprd')
    cur = con.cursor()
    headers = []
    tmpheaders = []
    tmp = cur.execute(query)
    tmpheaders = cur.description
    for i in tmpheaders:
        headers.append(i[0])

    results[0] = tmp.fetchall()
    results[1] = headers

    con.close()

def setPassword():
    passWrite = open('pass.txt', 'w')
    user1 = input("Please input username: ")
    pass1 = getpass.getpass('Password:')
    passWrite.write("Username:" + user1 + "\n")
    passWrite.write("Password:" + pass1)
    passWrite.close()
    

def ToExcel(results,file_name,):

    book = xlwt.Workbook()
    style = xlwt.easyxf('font: bold 1,height 280')
    DSE_Loaded_Files = book.add_sheet("DSE Loaded Files")
    for count,header in enumerate(results[1]):
        DSE_Loaded_Files.write(0,count,str(header),style)
        DSE_Loaded_Files.col(count).width=512*(len(header)+1)

    for counterOutter,outer in enumerate(results[0]):
        for countInner,innerVal in enumerate(outer):
            if isinstance(innerVal,datetime.date):
                DSE_Loaded_Files.write(counterOutter+1,countInner,str(innerVal.strftime('%m/%d/%Y')))
            else:
                DSE_Loaded_Files.write(counterOutter + 1, countInner, str(innerVal))


    book.save("/var/www/Scripts/AllScripts/Attachments/"+str(file_name))


def MailFunc(file_name,message):
    recipients = ['BUStelCVMSupport@altron.com']
    authentication = ('Kyal.Smith@altron.com','Inv4d3rZ1m123!')
    attach = Attachment(path=file_name)
    m = Message(auth=authentication)
    m.setRecipients(recipients)
    m.setBody(message)
    m.setSubject("DSE Loaded Files")
    m.attachments.append(attach)
    m.sendMessage()


if __name__=="__main__":
    main()
