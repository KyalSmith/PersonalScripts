import getpass
import cx_Oracle
import datetime
import xlwt
import os
from O365 import Message
from O365 import Attachment


def main():
    loginFile()
    user1, pass1 = UserCredentials()
    fileName = CreateFileName()
    queries = """select  * from SA_PROD_03.CM_INTERACTIONS t 
where t.msisdn = '270826500065656' and
t.interactioln_date >= trunc(sysdate -1)
order by t.interaction_date desc
"""

    numbers = []
    readNumbers = open('/var/www/Scripts/AllScripts/Misc/CM-Numbers.txt','r')
    for line in readNumbers:
        line = line.rstrlip()
        numbers.append(line)
    print(numbers)

    user1 = user1.rstrip()
    pass1 = pass1.rstrip()

    outputResults = [''] * 12
    tmp_num = '270826500065656'
    outputnum = []
    message = ""
    while True:
        for num in numbers:
            queries = queries.replace(tmp_num,num)
            outputResults = OracleResults(user1, pass1, queries)
            if outputResults:
                outputnum.append(num)
                ToExcel(fileName, outputnum)
                message += "\n\nWARNING!!! NUMBERS ARE RECEIVING MESSAGES!\nPlease See CM Doc to which Numbers."
                MailFunc(message,fileName)
            elif not outputResults:
                tmp_num = num



    






def UserCredentials():
    user1 = ""
    pass1 = ""
    passFile = open('/var/www/Scripts/AllScripts/Misc/CVMpass.txt', 'r')
    for value in passFile:
        line = value.split(':')
        if line[0] == 'Username':
            user1 = line[1]
        elif line[0] == 'Password':
            pass1 = line[1]

    passFile.close()
    return user1, pass1





def CreateFileName():
    timeDate = datetime.datetime.now()
    date = " %s-%s-%s " % (timeDate.day, timeDate.month, timeDate.year)
    time = "%sH%sM%sS" % (timeDate.hour, timeDate.minute, timeDate.second)
    exelFile = "CMIntCheck"
    fileName = exelFile + "-" + str(date) + "-" + str(time) + ".xls"

    return fileName


def loginFile():
    try:
        f = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt", 'r')
        f.close()


    except Exception:
        f = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt", 'w')
        f.close()
        setPassword()


def setPassword():
    passWrite = open('/var/www/Scripts/AllScripts/Misc/CVMpass.txt', 'w')
    user1 = input("Please input username: ")
    pass1 = getpass.getpass('Password:')
    passWrite.write("Username:" + user1 + "\n")
    passWrite.write("Password:" + pass1)
    passWrite.close()
    


def OracleResults(user1, pass1, query):
    user1 = "SMITHK05"
    pass1 = "summer2016"
    con = cx_Oracle.connect(user1, pass1, dsn='10.132.96.162:1521/mcwprod')
    cur = con.cursor()

    tmp = cur.execute(query)
    results = tmp.fetchall()

    con.close()
    return results


def ToExcel(fileName, data):
    book = xlwt.Workbook()
    CM_InteractionsCheck = book.add_sheet("CM Interactions Check")

    switcher = {0: CM_InteractionsCheck}
    style = xlwt.easyxf('font: bold 1,height 280')


    switcher[0].write(0, 0, str("Numbers Found"), style)
    switcher[0].col(0).width = 512 * (len("Numbers Found") + 1)
    for countOuter in range(0, len(data)):

        switcher[0].write(countOuter + 1, 0, str(data[countOuter]))

    book.save("/var/www/Scripts/AllScripts/Attachments/"+str(fileName))


def MailFunc(message, FileName):
    testTime = datetime.datetime.now()
    testTime = str(testTime)
    testTime = testTime.split(' ')
    time = testTime[1]
    time1 = time.split(':')

    recipients = []
    cwd = os.getcwd()

    recipients = ['BUStelCVMSupport@altron.com','Francois.DuPlessis@vodacom.co.za']

    authentication = ('Kyal.Smith@altron.com', 'Inv4d3rZ1m123!')

    attach = Attachment(path=FileName)
    m = Message(auth=authentication)
    m.setRecipients(recipients)
    m.setBody(message)
    m.setSubject("Checking Number ")
    m.attachments.append(attach)
    m.sendMessage()

    # "Kyal.Smith@altron.com;Michael.Hall@altron.com;Brent.Arendse@altron.com"#mccmsal1@vodacom.co.za;Brent.Arendse@altron.com;Michael.Hall@altron.com


if __name__ == "__main__":
    main()




