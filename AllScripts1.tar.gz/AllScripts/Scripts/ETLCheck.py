

import cx_Oracle
import getpass
from datetime import datetime
from O365 import Message
from O365 import Attachment
import xlwt
import os




def main():
    user1,pass1 = loginFile()
    spaces = 50
    queries = ReadQuery()
    time = str(datetime.now().time())
    time = time[:5]
    print(time)
    subject = ""
    #print(time)
    fileName = CreateFileName()
    Message=""
    etlResults = OracleResults(user1,pass1,queries[0])
    etlData = OracleResults(user1,pass1,queries[1])
    cdwData = OracleResults(user1,pass1,queries[2])
    ToExcel(fileName,etlData,cdwData)
    
    Message = "\n\nETL File Status:\n{0:<50}{1:50} Status_Code\n-----------------------------------------------------------------------------------------------------------------------------------------\n".format("Target_Table:","Start_Time:")
    for outer in etlResults:
        Message += "{0:<50} {1:<50} {2}\n".format(str(outer[0]),str(outer[1]),str(outer[2]))
        subject = "ETL Check and CDW File Information"
    
    #Message += formating(etlResults)

    if etlData:
        Message += "\nPlease see attachment for CDW File Information."
    elif not etlData:
        Message += "\nNote: Currently no Results regarding CDW File Information"
    print(Message)
    #print(etlResults)
    print(etlData)
    Message += "\n\nPlease Note: If '-1' appears in the CDW Results for multiple days a call needs to be logged with Mediation First Line Support or CDW  "

    return fileName,Message
    

def ReadQuery():
    query = ""
    file = open("/var/www/Scripts/AllScripts/Misc/ETLQueries.txt",'r')
    for val in file:
        query += val
    query = query.split("\n:\n")
    return query




def OracleResults(user1,pass1,query):

    con = cx_Oracle.connect(user1,pass1,dsn="pmcc001zatcax.vodacom.corp:1521/mccmIPRD")
    cur = con.cursor()

    tmp = cur.execute(query)
    results = tmp.fetchall()
    con.close()
    return results

def ToExcel(fileName,data,cdwData):
    book = xlwt.Workbook()
    tmpVal = [""]*6
    tmpVAl2 = [""] * 6
    CDW = book.add_sheet("CDW Files")
    FileCheck = book.add_sheet("Job Check")
    headersCDW = ["SUBSTR(PROCESS_NAME)","LOADED_RECORDS_TODAY","LOADED_RECORDS_ONE_DAY_AGO","LOADED_RECORDS_TWO_DAYS_AGO","LOADED_RECORDS_THREE_DAYS_AGO","LOADED_RECORDS_FOUR_DAYS_AGO"]
    headersFileCheck = ["Process_Name","Last_start_Time","Duration","Job_status","Missing_File","Total_Records"]
    style = xlwt.easyxf('font: bold 1,height 280')
    for count in range(len(headersCDW)):
        CDW.write(0, count, str(headersCDW[count]), style)
        CDW.col(count).width = 512 * (len(headersCDW[count]) + 1)

    for count in range(len(headersFileCheck)):
        FileCheck.write(0,count,str(headersFileCheck[count]),style)
        FileCheck.col(count).width = 512 * (len(headersFileCheck[count]) + 1)

    for countOuter in range(len(data)):
        tmpVal = [data[countOuter][0],data[countOuter][1],data[countOuter][2],data[countOuter][3],data[countOuter][4],data[countOuter][5]]
        for countInner in range(6):
            CDW.write((countOuter+1),countInner,tmpVal[countInner])

    for countOuter in range(len(cdwData)):
        tmpVAl2 = [cdwData[countOuter][0],str(cdwData[countOuter][1]),cdwData[countOuter][2],cdwData[countOuter][3],cdwData[countOuter][4],cdwData[countOuter][5]]
        for countInner in range(5):
            FileCheck.write(countOuter+1,countInner,tmpVAl2[countInner])
    book.save("/var/www/Scripts/AllScripts/Attachments/"+str(fileName))

def loginFile():
    user1 = ""
    pass1 = ""
    try:
        f = open("/var/www/Scripts/AllScripts/Misc/ETLpass.txt",'r')
        for val in f:
            val = val.split(":")
            if val[0] == "Username":
                user1 = val[1]
            elif val[0] == "Password":
                pass1 = val[1]
        f.close()

    except Exception:
        f = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt",'w')
        f.close()
        user1,pass1 = setPassword()
    user1 = user1.rstrip()
    pass1 = pass1.rstrip()
    return user1,pass1

def formating(results):
    spaces = 51
    iLength = 0
    Message =""
    for val in results:
        iLength = len(val[0])
        for count,innerVal in enumerate(val):
            if count != len(val)-1:
                Message += str(innerVal)
                for i in range(spaces - len(str(innerVal))):
                    Message += " "
            else:
                Message += str(innerVal) + "\n"
    return Message


def CreateFileName():
    timeDate = datetime.now()
    date = " %s-%s-%s " % (timeDate.day, timeDate.month, timeDate.year)
    time = "%sH%sM%sS" % (timeDate.hour, timeDate.minute, timeDate.second)
    exelFile = "ETLFileStatus.xls"
    fileName = exelFile + "-" + str(date) + "-" + str(time) + ".xls"

    return fileName




def setPassword():
    passWrite = open('/var/www/Scripts/AllScripts/Misc/CVMpass.txt', 'w')
    user1 = input("Please input username: ")
    pass1 = getpass.getpass('Password:')
    passWrite.write("Username:" + user1 + "\n")
    passWrite.write("Password:" + pass1)
    passWrite.close()
    passRead = open('/var/www/Scripts/AllScripts/Misc/CVMpass.txt','r')
    for val in passRead:
        print(val)
    passRead.close()
    return user1,pass1

def MailFunc(message,fileName,subject):
    cwd = os.getcwd()
    recipients = ['BUStelCVMSupport@altron.com']#,'Brent.Arendse@altron.com','Michael.Hall@altron.com'
    authentication = ('Kyal.Smith@altron.com','loatsu666!')
    m = Message(auth=authentication)
    attach = Attachment(path=str(cwd)+"/"+str(fileName))
    m.attachments.append(attach)
    m.setRecipients(recipients)
    m.setSubject(str(subject))
    m.setBody(message)
    m.sendMessage()
    print("Email Sent")


if __name__=="__main__":
	main()
