import os
import datetime
for file in os.listdir("/var/www/Scripts/AllScripts/Attachments/"):
    print(file)
testTime = datetime.datetime.now()
date = testTime.date()
date = str(date)
date = date.split('-')
date2 = []
for i in reversed(date):
    date2.append(i)
date = date2
print(date)


#print(TimeDate)
#testTime = testTime.split(' ')
#time = testTime[1]
#time1 = time.split(':')
