import getpass
import cx_Oracle
import datetime
import xlwt
import smtplib
from O365 import Message
from O365 import Attachment


def main():
    user1, pass1 = loginFile()
    fileName = CreateFileName()
    
    queries =["""select SERVER_ID, DIRECTION, ACCOUNT, count(*) from sa_prod_03.sa_sms_messages where RECORD_STATUS in ('L', 'A') group by SERVER_ID, DIRECTION, ACCOUNT order by SERVER_ID, DIRECTION, ACCOUNT"""]
    results = [''] * len(queries)
    Message = ""
    
    

    for count, item in enumerate(queries):
        tmpHeader, tmpResults = OracleResults(user1, pass1, item)
        results[count] = QueryResult(tmpResults, tmpHeader)
    if not results:
        Message="\n\nPending SMS Results:\nNote: No results found for Pending SMSs"
    ToExcel(results, fileName)
    #MailFunc(Message + "\n\nThank You", fileName)
    return fileName,Message


def UserCredentials():  # Reads User Credentials From the pass.txt File
    user1 = ""
    pass1 = ""
    passFile = open('/var/www/Scripts/AllScripts/Misc/CVMpass.txt', 'r')
    for value in passFile:
        line = value.split(':')
        if line[0] == 'Username':
            user1 = line[1]
        elif line[0] == 'Password':
            pass1 = line[1]
    user1 = user1.rstrip()
    pass1 = pass1.rstrip()
    passFile.close()
    return user1, pass1




def CreateFileName():  # Creates a dynamic filename using the date and time
    timeDate = datetime.datetime.now()
    date = " %s-%s-%s " % (timeDate.day, timeDate.month, timeDate.year)
    time = "%sH%sM%sS" % (timeDate.hour, timeDate.minute, timeDate.second)
    exelFile = "PendingSMS"
    fileName = exelFile + "-" + str(date) + "-" + str(time) + ".xls"

    return fileName


def loginFile():  # Confirming Oracle login credentials
    user1 = ""
    pass1 = ""
    try:  # Check if pass.txt file exists
        f = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt", 'r')
        if f:  # Check if the pass.txt file is not empty
            f.close()
            user1, pass1 = UserCredentials()


        else:
            f.close()
            user1, pass1 = setPassword()



    except Exception:
        f = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt", 'w')
        f.close()
        user1, pass1 = setPassword()

    return user1, pass1


def setPassword():  # Set Oracle Login credentials and save them in pass.txt if they dont exist.
    passWrite = open('/var/www/Scripts/AllScripts/Misc/CVMpass.txt', 'w')
    user1 = input("Please input username: ")
    pass1 = getpass.getpass('Password:')
    passWrite.write("Username:" + user1 + "\n")
    passWrite.write("Password:" + pass1)
    passWrite.close()
   
    return user1, pass1


def OracleResults(user1, pass1,
                  query):  # Run query against Oracle DB and store the results and the headers in the results list
    con = cx_Oracle.connect(user1, pass1, dsn='10.132.96.162:1521/mcwprod')
    cur = con.cursor()
    headers = []
    tmp = cur.execute(query)
    tmpheaders = cur.description
    for i in tmpheaders:
        headers.append(i[0])

    resultsInner = tmp.fetchall()
    return headers, resultsInner


def ToExcel(results, file_name, ):  # Write the Query results to an Excel spreadsheet with the appropriate Headers

    book = xlwt.Workbook()
    style = xlwt.easyxf('font: bold 1,height 280')
    
    sheets = [''] * len(results)
    
    for count in range(0, len(sheets)):
        sheets[count] = book.add_sheet("Query Result" + str(count + 1))

    for countResults, obs in enumerate(results):
        for count, header in enumerate(obs.headers):
            sheets[countResults].write(0, count, str(header), style)
            sheets[countResults].col(count).width = 512 * (len(header) + 1)

        for counterOutter, outer in enumerate(obs.dataResults):
            for countInner, innerVal in enumerate(outer):
                if isinstance(innerVal, datetime.date):
                    sheets[countResults].write(counterOutter + 1, countInner, str(innerVal.strftime('%m/%d/%Y')))
                else:
                    sheets[countResults].write(counterOutter + 1, countInner, str(innerVal))

    book.save("/var/www/Scripts/AllScripts/Attachments/"+str(file_name))


def MailFunc(message, FileName):
    testTime = datetime.datetime.now()
    testTime = str(testTime)
    testTime = testTime.split(' ')
    time = testTime[1]
    time1 = time.split(':')
    recipients = ['Kyal.Smith@Altron.com','Michael.Hall@altron.com','Brent.Arendse@altron.com']
    authentication=('Kyal.Smith@altron.com','Inv4d3rZ1m123!')
    attach = Attachment(path=FileName)
    m = Message(auth=authentication)
    m.setRecipients(recipients)
    m.setBody(message)
    m.setSubject("Current Pending SMSs")
    m.attachments.append(attach)
    m.sendMessage()


class QueryResult(object):
    dataResults = []
    headers = []

    def __init__(self, dataResults, headers):
        self.dataResults = dataResults
        self.headers = headers


if __name__ == "__main__":
    main()




