import subprocess
import getpass
import cx_Oracle
import xlwt
import os
from O365 import Message
from O365 import Attachment
from datetime import datetime


def main():
    Message = ""
    user1, pass1 = UserCreds()
    queries = GetQueries()
    results = [[]]*len(queries)
    fileName = CreateFileName()
    for count,val in enumerate(queries):
        results[count] = OracleResults(user1,pass1,val)
    ToExcelDoc(results,fileName)
    date = datetime.now()
    for item in results:
        if not item:
            Message += "\n\nCVM Previous Day Check:"
    if not results[0]:
        Message += "\nNote: Currently no Results for the GMR Wrapper"
    if not results[1]:
        Message += "\nNote: Currently no Results for the IBCI Wrapper"
    if not results[2]:
        Message += "\nNote: Currently no Results for the IBCM Wrapper"
    if not results[3]:
        Message += "\nNote: Currently no Results for the IBCP Wrapper"
    if not results[4]:
        Message += "\nNote: Currently no Results for the IMC Wrapper"
    if not results[5]:
        Message += "\nNote: Currently no Results for the NTFI Wrapper"
    if not results[6]:
        Message += "\nNote: Currently no Results for the OCS Wrapper"
    if not results[7]:
        Message += "\nNote: Currently no Results for the IBIM Wrapper"
    if not results[8]:
        Message += "\nNote: Currently no Results for the ILM Wrapper"
    if not results[9]:
        Message += "\nNote: Currently no Results for the MCCM Wrapper"
    if not results[10]:
        Message += "\nNote: Currently no Results for the PMG Wrapper"
    if not results[11]:
        Message += "\nNote: Currently no Results for the SMS Wrapper"
    if not results[12]:
        Message += "\nNote: Currently no Results for the RTI Wrapper"
    if not results[13]:
        Message += "\nNote: Currently no Results for the CIS Wrapper"
    if not results[14]:
        Message += "\nNote: Currently no Results for the MMSG Wrapper"
    
    return fileName,Message
        




def UserCreds():
    user1=""
    pass1=""
    tmpVal=""

    try:

        passFile = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt",'r')
        for val in passFile:
            tmpVal = val
            tmpVal = tmpVal.split(":")
            if tmpVal[0] == "Username":
                user1 = tmpVal[1]
            elif tmpVal[0] == "Password":
                pass1 = tmpVal[1]

    except FileNotFoundError:
        print("No password file found!")
        user1,pass1 = createPassFile()

    user1 = user1.rstrip()
    pass1 = pass1.rstrip()

    return user1,pass1

def createPassFile():
    user1 = input("Please enter username:")
    pass1 = getpass.getpass("Please enter password:")
    passWrite = open("/var/www/Scripts/AllScripts/Misc/CVMpass.txt",'w')
    passWrite.write("Username:"+user1+"\n")
    passWrite.write("Password:"+pass1)
    passWrite.close()
    return user1,pass1

def GetQueries():
    queriesFile = open("/var/www/Scripts/AllScripts/Misc/PrevDayQuery.txt",'r')
    queries = ""
    

    for val in queriesFile:
        queries += val
    
    queries = queries.split("\n:\n")

    return queries

def CreateFileName():
    dateTime = datetime.now()
    fileName = "CVM Previous Day "
    date = "%s-%s-%s"%(dateTime.day,dateTime.month,dateTime.year)
    time = "%sH%sM%sS"%(dateTime.hour,dateTime.minute,dateTime.second)
    fileName +=" " + date+ " "+time+".xls"
    return fileName

def OracleResults(username,password,query):
    
    con = cx_Oracle.connect(username,password,dsn='10.132.96.162:1521/mcwprod')
    cursor1 = con.cursor()
    
    tmp = cursor1.execute(query)
    finalResults = tmp.fetchall()

    con.close()




    return finalResults

def ToExcelDoc(results,fileName):
    tmpDate = ""
    book = xlwt.Workbook()
    GMR = book.add_sheet("GMR")
    IBCI = book.add_sheet("IBCI")
    IBCM = book.add_sheet("IBCM")
    IBCP = book.add_sheet("IBCP")
    IMC = book.add_sheet("IMC")
    NTFI = book.add_sheet("NTFI")
    OCS = book.add_sheet("OCS")
    IBIM = book.add_sheet("IBIM")
    ILM = book.add_sheet("ILM")
    MCCM = book.add_sheet("MCCM")
    PMG = book.add_sheet("PMG")
    SMS = book.add_sheet("SMS")
    RTI = book.add_sheet("RTI")
    CIS = book.add_sheet("CIS")
    MMSG = book.add_sheet("MMSG")
    switcher = {0: GMR, 1: IBCI, 2: IBCM, 3: IBCP, 4: IMC, 5: NTFI, 6: OCS, 7: IBIM, 8: ILM, 9: MCCM, 10: PMG, 11: SMS,12: RTI,13:CIS,14:MMSG}
    style = xlwt.easyxf('font: bold 1,height 280')
    headers = ["Date:", "Hour:", "TXN_Type:", "Server_Name:", "TXN_Count:", "EXP_Count:", "EXP_Percent:"]
    for countOuter in range(0,len(results)):

        for count in range(0,7):
            switcher[countOuter].write(0,count,str(headers[count]),style)
            switcher[countOuter].col(count).width = 512 * (len(headers[count])+1)


        for countInner in range(0,len(results[countOuter])):

            for finalCount in range(0,len(results[countOuter][countInner])):
                if isinstance(results[countOuter][countInner][finalCount],datetime):
                    tmpDate = str(results[countOuter][countInner][finalCount].date())
                    switcher[countOuter].write(countInner+1,finalCount,tmpDate)
                else:
                    switcher[countOuter].write(countInner + 1, finalCount, results[countOuter][countInner][finalCount])

    book.save("/var/www/Scripts/AllScripts/Attachments/" + str(fileName))


def MailFunc(message, fileName):

    cwd = os.getcwd()
    recipients = ['Kyal.Smith@altron.com','Brent.Arendse@altron.com', 'Michael.Hall@altron.com','Francois.DuPlessis@vodacom.co.za']#
    authentication = ('Kyal.Smith@altron.com', 'Inv4d3rZ1m123!')
    m = Message(auth=authentication)
    attach = Attachment(path=str(cwd) + "/" + str(fileName))
    m.attachments.append(attach)
    m.setRecipients(recipients)
    m.setSubject(str("CVM Previous Day"))
    m.setBody(message)
    m.sendMessage()
    print("Email Sent")
    
    



        





if __name__=="__main__":
    main()
